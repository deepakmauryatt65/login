<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Add Test Paper </title>
  <!--favicon-->
  <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon"/>
  <!-- Vector CSS -->
  <link href="assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
  
  <style>
  .dash-pad{padding:40px 0px;}
  </style>
  
</head>

<body>

<!-- Start wrapper-->
 <div id="wrapper">
 
 
 <!--Start sidebar-wrapper-->
        <?php include('includes/sidebar.php') ?>
   <!--End sidebar-wrapper-->

<!--Start topbar header-->
       <?php include('includes/header-top.php') ?>
<!--End topbar header-->


<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
	    <div class="col-sm-1"></div>
        <div class="col-sm-10">
		    <h4 class="page-title">Add Test Paper </h4>
		    <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Add Test Paper </li>
         </ol>
	   </div>
     </div>
    <!-- End Breadcrumb-->


    <div class="row">
	  <div class="col-lg-1"></div>
      <div class="col-lg-10">
         <div class="card">
           <div class="card-body">
           <hr>
		   
           <form action="#" method="post">			
			
           <div class="form-group">
            <label for="input-2">Test Paper Name</label>
            <input type="text" class="form-control" name="paper" placeholder="Test Paper Name" required>
           </div>
		   
		   <div class="form-group">
            <label for="input-2">Add Price</label>
            <input type="text" class="form-control" name="paper" placeholder="Rs 350.00" required>
           </div>
		   
		   <div class="form-group">
            <label for="input-3">Description</label>
            <textarea rows="4" class="form-control" name="description" id="basic-textarea" placeholder="Enter Description" required></textarea>
           </div>
            
		   <div class="col-md-6">
           <div class="form-group">
            <button type="submit" class="btn btn-primary px-5"><i class="icon-lock"></i> Create Test Paper</button>
          </div>
          </div>
		  
          </form>
		  
         </div>
         </div>
      </div>
	  
    </div><!--End Row-->



    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
   
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
   
  </div><!--End wrapper-->

<script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>

  <!--Bootstrap Touchspin Js-->
    <script src="assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.js"></script>
    <script src="assets/plugins/bootstrap-touchspin/js/bootstrap-touchspin-script.js"></script>

    <!--Select Plugins Js-->
    <script src="assets/plugins/select2/js/select2.min.js"></script>
    <!--Inputtags Js-->
    <script src="assets/plugins/inputtags/js/bootstrap-tagsinput.js"></script>

    <!--Bootstrap Datepicker Js-->
    <script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script>
      $('#default-datepicker').datepicker({
        todayHighlight: true
      });
      $('#autoclose-datepicker').datepicker({
        autoclose: true,
        todayHighlight: true
      });

      $('#inline-datepicker').datepicker({
         todayHighlight: true
      });

      $('#dateragne-picker .input-daterange').datepicker({
       });

    </script>


  
</body>
</html>
