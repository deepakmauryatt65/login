<?php
$i=1;
if($i==1):
	echo 'working';
   endif;

 ?>