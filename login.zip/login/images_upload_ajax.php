<?php 

function image_check($im_name,$pathtoupload,$val)
{ $val=$val;
	if($val==1)
	{
	$img_name=$im_name;
	$path=$pathtoupload;
	
	//echo $img_name."-->".$path;
	$uploadOk = 1;
	$target_dir = $path;
	$imgname=basename($_FILES[$img_name]["name"]);
	$target_file =$target_dir . basename($_FILES[$img_name]["name"]);
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
					
				 
					if ($_FILES[$img_name]["size"] > 1024000) 
					{
								
								  echo 'Upload Failed Sorry, your image file is too large Allow Size is 1 MB or 1024 kb. Your File is : ';
								
							$uploadOk = 0;
							
					}
					else if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
						&& $imageFileType != "gif" && $imageFileType != "webp" ) 
					{
								
								  echo 'Upload Failed Sorry, only JPG, JPEG, PNG, WEBP & GIF image files are allowed. Your File is : ';
								
								$uploadOk = 0;
								
					}
					
					else {}
												
										if($uploadOk == 1)
										{
										
										if (move_uploaded_file($_FILES[$img_name]["tmp_name"], $target_file)) 
															{
																	
																	  echo 'Upload Successful Your File is :';
																	
															} else {
																
																	  echo 'Sorry, there was an error uploading your image file';
																	
																	
															}
										
									}
									
									
									return $imgname;
	}
}


if(isset($_FILES['file']))
{
	
	$name="file";
	$path="upload/";
	$result=image_check($name,$path,1);
	echo $result; 
}





?>