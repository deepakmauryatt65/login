<?php
session_start();
if(!isset($_SESSION['login_id']))
echo '<script> window.location.href="signin.php"; </script>';	
?>