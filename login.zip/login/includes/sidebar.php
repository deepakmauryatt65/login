  <link href="assets/css/sidebar-menu.css" rel="stylesheet"/>
   <script src="assets/js/sidebar-menu.js"></script>
  <script src="assets/js/jquery.min.js"></script>
 <!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" class="bg-theme bg-theme2" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="index.php">
       <img src="assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text">Coaching Class</h5>
     </a>
   </div>
   <div class="user-details">
	  <div class="media align-items-center user-pointer collapsed" data-toggle="collapse" data-target="#user-dropdown">
	    <div class="avatar"><img class="mr-3 side-user-img" id="ddd" src="assets/images/avatars/avatar-13.png" data-html="true" 
		alt="user avatar"></div>
	     <div class="media-body">
	     <h6 class="side-user-name">Nitesh Shrivastava</h6>
	    </div>
       </div>
	   <div id="user-dropdown" class="collapse">
		  <ul class="user-setting-menu">
            <li><a href="javaScript:void();"><i class="icon-user"></i>  My Profile</a></li>
            <li><a href="javaScript:void();"><i class="icon-settings"></i> Setting</a></li>
			<li><a href="logout.php"><i class="icon-power"></i> Logout</a></li>
		  </ul>
	   </div>
      </div>
	  <script>
/* $(document).ready(function(){
  $("#ddd").mouseover(function(){
	  
	  var dd="nitesh<br>srivastava";
    $("#ddd").attr("title", dd);
  });
  
}); */
</script>
   <ul class="sidebar-menu do-nicescrol">
      <li class="sidebar-header">MAIN NAVIGATION</li>
	  
      <li><a href="index.php" class="waves-effect"><i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span></a></li>
	  
	  
		    <li>
			   <a href="#" class="waves-effect">
			    <i class="zmdi zmdi-view-dashboard"></i> <span>Manage Category</span><i class="fa fa-angle-left pull-right"></i>
			   </a>
			<ul class="sidebar-submenu">
			  <li><a href="view-all-category.php"><i class="zmdi zmdi-long-arrow-right"></i>All Category</a></li>
			  <li><a href="view-all-sub-category.php"><i class="zmdi zmdi-long-arrow-right"></i>All Sub Category</a></li>
			</ul>
            </li>
			
			
			
			
			
			
	  
    </ul>
   
   </div>
   <!--End sidebar-wrapper-->


