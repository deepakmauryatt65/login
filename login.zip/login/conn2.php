

<?php
$serverName = "101.53.144.215,2498"; //serverName\instanceName
$connectionInfo = array( "Database"=>"smith_school_Test", "UID"=>"smithSchoolTestUser1", "PWD"=>"Rhd8a*64");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     echo "Connection established.<br />";
}else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}


?>

