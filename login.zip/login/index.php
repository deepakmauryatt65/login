<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Dashboard</title>
  <!--favicon-->
  <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
  <!-- simplebar CSS-->
  <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
 
</head>

<body>
<!-- Start wrapper-->
 <div id="wrapper">

 <!--Start sidebar-wrapper-->
        <?php include('includes/sidebar.php') ?>
   <!--End sidebar-wrapper-->

<!--Start topbar header-->
       <?php include('includes/header-top.php') ?>
<!--End topbar header-->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

  <div class="row mt-3">
    <div class="col-12 col-lg-6 col-xl-3">
      <div class="card gradient-scooter">
       <div class="card-body">
          <div class="media align-items-center">
            <div class="w-icon"><i class="fa fa-comments-o text-white"></i></div>
            <div class="media-body ml-3 border-left-xs border-white-2">
              <p class="mb-0 ml-3 extra-small-font text-white">All Users</p>
            </div>
          </div>
        </div>
      </div>
     </div>

     <div class="col-12 col-lg-6 col-xl-3">
      <div class="card gradient-bloody">
       <div class="card-body">
          <div class="media align-items-center">
            <div class="w-icon"><i class="fa fa-question-circle-o text-white"></i></div>
            <div class="media-body ml-3 border-left-xs border-white-2">
              <p class="mb-0 ml-3 extra-small-font text-white">All Test Paper</p>
            </div>
          </div>
        </div>
      </div>
     </div>

     <div class="col-12 col-lg-6 col-xl-3">
      <div class="card gradient-quepal">
       <div class="card-body">
          <div class="media align-items-center">
            <div class="w-icon"><i class="fa fa-bar-chart text-white"></i></div>
            <div class="media-body ml-3 border-left-xs border-white-2">
              <p class="mb-0 ml-3 extra-small-font text-white">All Test Series</p>
            </div>
          </div>
        </div>
      </div>
     </div>

     <div class="col-12 col-lg-6 col-xl-3">
      <div class="card gradient-blooker">
       <div class="card-body">
          <div class="media align-items-center">
            <div class="w-icon"><i class="fa fa-money text-white"></i></div>
            <div class="media-body ml-3 border-left-xs border-white-2">
              <p class="mb-0 ml-3 extra-small-font text-white">All Question Paper</p>
            </div>
          </div>
        </div>
      </div>
     </div>

   </div><!--End Row-->
   
   <div class="row mt-3">
    <div class="col-12 col-lg-6 col-xl-3">
      <div class="card gradient-scooter">
       <div class="card-body">
          <div class="media align-items-center">
            <div class="w-icon"><i class="fa fa-comments-o text-white"></i></div>
            <div class="media-body ml-3 border-left-xs border-white-2">
              <p class="mb-0 ml-3 extra-small-font text-white">All Income</p>
            </div>
          </div>
        </div>
      </div>
     </div>

     <div class="col-12 col-lg-6 col-xl-3">
      <div class="card gradient-bloody">
       <div class="card-body">
          <div class="media align-items-center">
            <div class="w-icon"><i class="fa fa-question-circle-o text-white"></i></div>
            <div class="media-body ml-3 border-left-xs border-white-2">
              <p class="mb-0 ml-3 extra-small-font text-white">All Invoice</p>
            </div>
          </div>
        </div>
      </div>
     </div>

   </div><!--End Row-->
   
  
    </div>
    <!-- End container-fluid-->

   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	
  </div><!--End wrapper-->
  

  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>

  <!-- Chart js -->
  <script src="assets/plugins/Chart.js/Chart.min.js"></script>
  <!--Peity Chart -->
  <script src="assets/plugins/peity/jquery.peity.min.js"></script>
  <!-- Index2 js -->
  <script src="assets/js/service-support.js"></script>

</body>
</html>
